<?php

class auth extends AppController {

    public function __construct() {
        
    }

    public function login() {

        if($_REQUEST["email"] && $_REQUEST["password"]) {
            if($_REQUEST["email"] == "gri.y8s@gmail.com" && $_REQUEST["password"] == "pass") {
                $_SESSION["loggedin"] = 1;
                header("Location:/home");
            }
            else {
                header("Location:/home?msg=Bad Login");
            }
        }
        else {
            header("Location:/home?msg=Bad Login");
        }
    }

    public function logout() {
        session_destroy();
        header("Location:/home");
    }
}

?>