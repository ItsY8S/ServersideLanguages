<?php

class profile extends AppController {

    public function __construct() {



        if(@$_SESSION["loggedin"] && @$_SESSION["loggedin"] == 1) {

        }
        else {
            header("Location:/home");
        }
    }

    public function index() {
        $menu = array("home" => "home", "api" => "api", "crud" => "crud", "about" => "about");

        $this->getView("components/header", array("pagename"=>"home"));

        $this->getView("components/navigation", $menu);

        $this->getView("components/body");

        $this->getView("home");

        $this->getView("components/footer");
    }

}

?>