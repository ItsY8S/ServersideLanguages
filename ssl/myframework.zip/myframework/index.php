<?php

include 'bin/config.php'

?>