<div class="row">
    <div class="col-sm">
        <h1>About</h1>
        <?php
            $this->getView("components/carousel");
            $this->getView("components/progressBar");
            $this->getView("components/modal");
            $this->getView("components/popover");
        ?>
    </div>
</div>