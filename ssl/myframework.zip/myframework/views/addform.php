<div class="row">
<div class="col-6 offset-1" style="margin-top: 15px; margin-left: 70px;">
<form action="/about/addAction" method="POST">
    <h3>Add a fruit</h3>
    <input name="name" type="text" placeholder="Fruit" />
    <input type="submit" />

    </form>
</div>
    
</div>
