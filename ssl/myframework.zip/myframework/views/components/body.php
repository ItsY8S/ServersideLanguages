<?php

// Start the container
echo "<div class='container'>";

?>