<?php

echo "<button type='button' class='btn btn-secondary' data-container='body' data-toggle='popover' data-placement='right' data-content='Vivamus sagittis lacus vel augue laoreet rutrum faucibus.'>";
echo "Popover on top";
echo "</button>";

?>