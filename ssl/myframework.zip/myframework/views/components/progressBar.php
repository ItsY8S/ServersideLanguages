<?php

echo "<div class='progress'>";
echo "<div class='progress-bar w-75' role='progressbar' aria-valuenow='75' aria-valuemin='0' aria-valuemax='100'></div>";
echo "</div>";

?>