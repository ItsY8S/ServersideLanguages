<div class="row panel">
    <div class="col-md-12 col-xs-12">
        <img src="../assets//img/person.jpg" class="img-thumbnail" style="width:100px; height: 100px;" picture hidden-xs" />
        <br />
        <form action="/profile/update" method="post" enctype="multipart/form-data">
            <input name="img" type="file" style="display: block" />
            <input type="text" name="test" value="Test" />
            <input type="submit" value="Update" class="btn btn-primary">
        </form>

        <div class="header">
            <h1>Jane Doe</h1>
            <h4>Web Developer</h4>
            <span> This is about me. This is about me. This is about me. This is about me. This is about me. This is about me.</span>
        </div>
    </div>
</div>